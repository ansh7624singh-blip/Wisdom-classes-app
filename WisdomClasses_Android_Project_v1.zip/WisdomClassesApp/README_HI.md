# WISDOM CLASSES Android App — Version 1.0 Starter

## इसमें क्या है
- Navy Blue + Gold थीम और दिया गया Wisdom Classes लोगो
- Splash, Welcome, Student Login और Admin Login
- Admin dashboard: Total Students, Present Today, Fees Pending, Fees Collected
- Add / Manage Student, Attendance, Fees, Routine, Notices, Exams, Study Materials, Chat, Topper Board
- Student dashboard: Home, Routine, Fees, Gallery, Profile
- Student services: Notifications, Exam Report, Attendance, Student–Admin Chat, Study Materials, Exam Schedule, Topper Board, Report Card
- Online payment पूरी तरह हटाया गया है।

## Demo login
- Admin: `admin@wisdomclasses.in` / `Admin123`
- Student: `WC1001` / `student123`

## जरूरी सीमा
यह अभी **लोकल डेमो / starter build** है। डेटा इसी डिवाइस के WebView local storage में रहता है। अलग-अलग मोबाइलों में साझा डेटा, सुरक्षित वास्तविक Admin authentication, PDF upload/storage, push notifications और असली report-card PDF के लिए Firebase project/configuration और backend rules जोड़ना बाकी है। Demo credentials को production में इस्तेमाल न करें।

## APK बनाने के लिए
1. Android Studio में इस पूरे फ़ोल्डर को Open करें।
2. Gradle sync पूरा होने दें (Android SDK 35 और compatible Gradle/Android plugin की जरूरत है)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

इस रनटाइम में Android SDK/Gradle उपलब्ध नहीं था, इसलिए यहाँ वास्तविक APK compile करके देना संभव नहीं हुआ। यह ZIP पूरा Android Studio source project है, APK नहीं।
